-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2022 at 10:43 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `report_card`
--

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` int(11) NOT NULL,
  `className` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `className`) VALUES
(2, 'Form 1'),
(3, 'Form 2'),
(4, 'Form 3'),
(5, 'Form 4'),
(6, 'Form 5'),
(7, 'Lower Sixth'),
(24, 'Upper Sixth 2');

-- --------------------------------------------------------

--
-- Table structure for table `import_info`
--

CREATE TABLE `import_info` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `dateOfBirth` date NOT NULL,
  `age` int(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `fileName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `import_info`
--

INSERT INTO `import_info` (`id`, `name`, `class`, `dateOfBirth`, `age`, `gender`, `fileName`) VALUES
(2, 'Steven jobs', 'Form 3', '2022-06-17', 22, 'Male', 'Results.xlsx');

-- --------------------------------------------------------

--
-- Table structure for table `import_marks`
--

CREATE TABLE `import_marks` (
  `id` int(11) NOT NULL,
  `names` varchar(255) NOT NULL,
  `sub1` int(255) NOT NULL,
  `sub2` int(255) NOT NULL,
  `sub3` int(255) NOT NULL,
  `sub4` int(255) NOT NULL,
  `sub5` int(255) NOT NULL,
  `sub6` int(255) NOT NULL,
  `sub7` int(255) NOT NULL,
  `sub8` int(255) NOT NULL,
  `sub9` int(255) NOT NULL,
  `sub10` int(255) NOT NULL,
  `sub11` int(255) NOT NULL,
  `total` int(255) NOT NULL,
  `average` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `import_marks`
--

INSERT INTO `import_marks` (`id`, `names`, `sub1`, `sub2`, `sub3`, `sub4`, `sub5`, `sub6`, `sub7`, `sub8`, `sub9`, `sub10`, `sub11`, `total`, `average`) VALUES
(59, 'Steven job', 12, 12, 10, 11, 9, 7, 17, 16, 14, 14, 11, 133, 12.0909),
(60, 'Eric Halter ', 11, 11, 12, 15, 14, 13, 13, 19, 7, 19, 9, 143, 13),
(61, 'John micheal', 19, 10, 7, 18, 10, 12, 13, 17, 9, 18, 11, 144, 13.0909),
(62, 'Sabrina halt', 6, 14, 9, 16, 18, 15, 13, 16, 11, 15, 18, 151, 13.7273),
(63, 'Peter Paker', 7, 18, 11, 9, 12, 17, 12, 15, 13, 14, 14, 142, 12.9091),
(64, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(65, 'Steven job', 12, 12, 10, 11, 9, 7, 17, 16, 14, 14, 11, 133, 12.0909),
(66, 'Eric Halter ', 11, 11, 12, 15, 14, 13, 13, 19, 7, 19, 9, 143, 13),
(67, 'John micheal', 19, 10, 7, 18, 10, 12, 13, 17, 9, 18, 11, 144, 13.0909),
(68, 'Sabrina halt', 6, 14, 9, 16, 18, 15, 13, 16, 11, 15, 18, 151, 13.7273),
(69, 'Peter Paker', 7, 18, 11, 9, 12, 17, 12, 15, 13, 14, 14, 142, 12.9091);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `code` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `code`) VALUES
(11, 'Morel Denzel', 'mtchaptche@gmail.com', 8391);

-- --------------------------------------------------------

--
-- Table structure for table `records`
--

CREATE TABLE `records` (
  `id` int(11) NOT NULL,
  `fullName` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `mark` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `records`
--

INSERT INTO `records` (`id`, `fullName`, `subject`, `mark`) VALUES
(31, 'Mary Noel', 'mathematics', 12),
(32, 'Mary Noel', 'English', 11),
(33, 'Mary Noel', 'French', 8),
(34, 'Mary Noel', 'Physics', 17),
(35, 'Mary Noel', 'chemistry', 10),
(36, 'Mary Noel', 'biology', 11),
(37, 'Mark gate', 'mathematics', 17),
(38, 'Mark gate', 'English', 19),
(39, 'Mark gate', 'French', 16),
(40, 'Mark gate', 'Physics', 20),
(41, 'Mark gate', 'chemistry', 19),
(42, 'Mark gate', 'biology', 18),
(53, 'bruno  Mars', 'Litterature', 19),
(54, 'bruno  Mars', 'history', 11),
(55, 'bruno  Mars', 'citizenship', 8),
(56, 'bruno  Mars', 'french', 11),
(57, 'Sabrina Carpenter', 'Litterature', 10),
(58, 'Sabrina Carpenter', 'history', 11),
(59, 'Sabrina Carpenter', 'citizenship', 9),
(60, 'Sabrina Carpenter', 'french', 16),
(61, 'Mark gates', 'mathematics', 12),
(62, 'Mark gates', 'English', 9),
(63, 'Mark gates', 'French', 14),
(64, 'Mark gates', 'Physics', 16),
(65, 'Mark gates', 'chemistry', 9),
(66, 'Mark gates', 'biology', 7),
(67, 'Mark gates', 'Geography', 12),
(68, 'Mark gates', 'Economics', 19),
(69, 'Mark gates', 'Logic', 10);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `fName` varchar(255) NOT NULL,
  `lName` varchar(255) NOT NULL,
  `studentClass` varchar(255) NOT NULL,
  `dateOfBirth` date NOT NULL,
  `age` int(255) NOT NULL,
  `gender` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `fName`, `lName`, `studentClass`, `dateOfBirth`, `age`, `gender`) VALUES
(1, 'Mary', 'Noel', 'Form 1', '2001-03-08', 21, 'Female'),
(2, 'Silver', 'Juliette', 'Form 1', '2004-05-17', 19, 'Female'),
(3, 'Mark', 'gates', 'Form 1', '2002-12-21', 20, 'Male'),
(5, 'Henry', 'Berk', 'Form 1', '2002-10-17', 21, 'Male'),
(6, 'shawn', 'mendes', 'Form 2', '2001-03-03', 21, 'Male'),
(7, 'bruno ', 'Mars', 'Form 2', '2001-03-18', 21, 'Male'),
(8, 'Sabrina', 'Carpenter', 'Form 2', '2000-12-19', 22, 'Female'),
(9, 'Mary', 'mendes', 'Form 1', '2001-07-14', 21, 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `subjectName` varchar(255) NOT NULL,
  `subjectClassName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `subjectName`, `subjectClassName`) VALUES
(2, 'mathematics', 'Form 1'),
(3, 'English', 'Form 1'),
(4, 'French', 'Form 1'),
(5, 'Physics', 'Form 1'),
(6, 'chemistry', 'Form 1'),
(7, 'biology', 'Form 1'),
(10, 'citizenship', 'Form 2'),
(11, 'french', 'Form 2'),
(13, 'mathematics', 'Upper Sixth 2'),
(14, 'French', 'Upper Sixth 2'),
(16, 'Geography', 'Form 1'),
(17, 'Economics', 'Form 1'),
(18, 'Logic', 'Form 1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `import_info`
--
ALTER TABLE `import_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `import_marks`
--
ALTER TABLE `import_marks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `records`
--
ALTER TABLE `records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `import_info`
--
ALTER TABLE `import_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `import_marks`
--
ALTER TABLE `import_marks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `records`
--
ALTER TABLE `records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
